let menu = [
    {
        id: 1,
        title: "buttermilk pancakes",
        category: "breakfast",
        price: 15.99,
        img: "images/beans.jpg",
        desc: "Beans, nutritious and healthy. Grab your beans now!!"
    
    }, 
    
    {
        id:2,
        title: "diner double",
        category: "lunch",
        price: 20.45,
        img : "images/garri.jpg",
        desc: "Garri, sweet and delicious"
    },
    
    
    {
        id:3,
        title: "Foodstuff",
        category: "lunch",
        price: 20.45,
        img : "images/foodstuff.jpg",
        desc: "Got delciious yam waiting for you"
    },
    
    {
        id:4,
        title: "Malt",
        category: "dinner",
        price: 20.45,
        img : "images/malt.jpg",
        desc: "Foodstuff making waves inthe food industry"
    },
    
    {
        id:5,
        title: "Fish",
        category: "dinner",
        price: 20.45,
        img : "images/fish.jpg",
        desc: "Foodstuff making waves inthe food industry"
    },
    
    
    ]
    let index = 0;

    window.addEventListener("DOMContentLoaded", function(){
    

    })
  
let filterbuttons = document.querySelectorAll(".filter-btn");
filterbuttons.forEach((singleBtn)=>{
    singleBtn.addEventListener("click", function(e){
        let category = e.currentTarget.dataset.id;
        console.log(category);

        let filteredMenu = menu.filter(function(singleCategory){
          if(singleCategory.category === category){
            return singleCategory
          }
        })

        if(category === "all"){
            displayMenu(menu)
        }
        else{
            displayMenu(filteredMenu)
        }
    })
})



displayMenu(); 
let imgArray = ["images/garri.jpg", "images/foodstuff.jpg",  "images/beans.jpg", "images/thyme.jpg"]
let index2 = 0;
function slider(){
let pic = document.querySelector(".pj1");

if(index2 < imgArray.length){
pic.src = imgArray[index]
index++
}
else{
index2 = 0;
pic.src = imgArray[index]
}

}


let set = setInterval(slider, 1000);
let sectionCenter = document.querySelector(".section-center")

    function displayMenu(menu1){
    
        let display = menu1.map((singleDish)=> {
            return `
            <article class="menu-item">
                    <img src="${singleDish.img}" alt="menu item" class="photo"/>

                    <div class ="item-info">
                        <header>
                        <h4>${singleDish.title}</h4>
                        <h4 class="price">${singleDish.price}</h4>
                    </header>

                    <p class="item-text">${singleDish.desc}</p>
                </div>
                </article>
            
            `
        })
      
  display = display.join(" ");
  sectionCenter.innerHTML = display;
    }


let nav  = document.querySelector(".navigation");
let up =document.querySelector("#up");
window.addEventListener("scroll", function(){
    let scrollHeight = window.pageYOffset;
    let navHeight = nav.getBoundingClientRect().height;
    if(scrollHeight > navHeight){
        nav.classList.add("fixed-nav")
    }
    else{
        nav.classList.remove("fixed-nav")
    }

    if(scrollHeight > 100){
up.style.visibility = "visible"
    }
    else{
        up.style.visibility = "hidden" 
    }
})