function Number1(){
    let array1 = [1,2,3,4,5,6,7,8,9,10];

    this.no1 = 1;
    this.no2 = 2;
    this.no3 = 3;
    this.no4 = 4;
    this.no5 =5;
    this.no6 = 6;
    this.no7 = 7; 
    this.no8 = 8;
    this.no9 = 9;
    this.no10 = 10;
}

function Number2(){

}
let array1 = [1,2,3,4,5,6,7,8,9,10];
let array2 = [0];
let b3 = array2.push(array1[0,1,2,3,4]);
console.log(b3)


function Human( complexion, hairColor, height){
    var private =67; //use var only for private variables inside a constructor it is undefined beacuse it is only local to the Human scope
   //f the local variable can't access the private variable then the inherited one can't access it too
    this.humanColor= complexion;
    this.color_of_hair= hairColor;
    this.height = height;

    this.show_detail= function(){//public metod because this is used
       // return "From inside the constructor" + this.hair + this.eye
        //this.private = 18;
        return private;
    }

    var privateMethod = function(){// this is a private method and it wil not display the value, a private variable can only be invoked within the same scope
        //this.private = 18;
        return this.private
    }

}
//creating another public function that is accessible using the prototype of the constructor
Human.prototype.myFunc = function(){
console.log("prototyping");
}

let h1 = new Human();
Human.prototype.car = "true";
console.log(h1);

let pHuman = new Human( "bsc", "black", "blue");
console.log(pHuman.show_detail());
console.log(pHuman.privateMethod);
console.log(pHuman.humanColor);
console.log(pHuman.myFunc())

Human.prototype.x = '123';
Human.prototype.y = '012';


function person(fname, lname, bloodGroup,age, qualifications, hairColor, eyeColor){
    Human.call(this, age, qualifications, hairColor, eyeColor) //CALL TAKES AN OBJECT AND THE PARAMETERS ASSIGNED TO THE HUMAN function
  this.firstName = fname;
  this.lastName = lname;
  this.blood = bloodGroup;
}


person.prototype = new Human();
person.prototype.constructor = person;

//x.y object.property;
//x.y.z// solve from z to x

let p1 = new person("aki", "babaiola", "o+");
console.log(p1.show_detail());
console.log(p1.car)

function outerFunction(outer){
    console.log("This is the outer variable"+ outer);
    outer++;
function innerFunction(inner){
        let add = outer+ inner
        console.log("This si an inner function" + add);
    }

    return innerFunction
}

let o1 = outerFunction(10);
o1(20);

let a = null;


function h12(name, color, age, location){ 
    this.naming = name;
    this.firstcolor = color;
    this.personAge = age;
    this.location1 = location;
}

let house = new h12("Jenny", "blue", 20, "4 irepodun avenue");
house.year = "2003";
console.log(house);


function secondh12(school, game, qualification, fruit, name, color, age, location){
    h12.call(this, name, color, age, location);
    this.schoolName = school;
    this.gameName = game;
    this.qualified = qualification;
    this.food = fruit;
}
secondh12.prototype = new h12();
secondh12.prototype.constructor = secondh12;

let h11 = new secondh12("al murooj", "COD", "BSC", "banana", "Jenny", "red", 12, "4 irepodun");
console.log(h11.gameName);


//oop Functions

function firstFunction(name, age, status){
    this.name = name;
    this.age = age;
    this.status = status;

    this.dFunction = function(){
        return this.age + this.status
    }

}

function secondFunction(dreams, visions, stories, name, age, status ){
    firstFunction.call(this, name, age, status)
    this.dreams = dreams;
    this.visions = visions;
    this.stories = stories;


}

let s1 = new secondFunction("cute", "missionaries", "cutie", "Jenny", 22, "single");
console.log(s1.dreams);


function thirdFunction(third, fourth, fifth, dreams, visions, stories){
    secondFunction.call(this, dreams, visions, stories);
    this.dreams = dreams;
    this.visions = visions;
    this.stories = stories;



}

let t = new thirdFunction(3, 4,5, "an inventor", "my vision", "my story");
console.log(t);

thirdFunction.prototype = new secondFunction;
thirdFunction.prototype.constructor = firstFunction;

let f = new thirdFunction(3,4,5,"to kearn how to fly","to build my hourse", "eat and sleep well");
console.log(f);

function external (outerf){

outerf++;
return function inner(inside){
    let add = outerf+ inside;
    console.log("This is the value inside the function" + add);

}
}

let e2 = external(10);
e2(6);



function closureFunction(closer){
    closer++;
    console.log("This is the new value of the closure function" + closer);

    function innerFunction(inner){
       let add = closer + inner;
       console.log("This is the addition of two numbers" + add) 
    }

    return innerFunction
}

let closing = closureFunction(23);
closing(34);




