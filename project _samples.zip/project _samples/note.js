
/*var canvasElement = canvas.getContext('2d');
canvasElement.font = "12rem Arial";
canvasElement.fillStyle = "red";
canvasElement.textAlign = "center";
canvasElement.fillText("Notes App", canvas.width/2, canvas.height/2);
canvasElement.font = "4rem Arial";
canvasElement.fillText("Where you can write any of your", canvas.width/2, canvas.height/2);*/

var title = document.querySelector(".title");
title.width = window.innerWidth;
title.height = window.innerHeight;
var titleElement = title.getContext("2d");
titleElement.font = "4rem Arial";
titleElement.fillStyle = "black";
titleElement.textAlign = "center";
titleElement.fillText("Notes App", title.width/2, title.height/2);


for(let i = 0; i< 6; i++){
    let color = "#" + Math.random().toString(16).substr(2, 6);
    let x = Math.random() * window.innerWidth;
    let y = Math.random() * window.innerHeight;
    
    titleElement.beginPath();
    titleElement.arc(x, y, 60, 0, Math.PI* 2, false);
    titleElement.fillStyle = color;
    titleElement.fill();

}

var title2 = document.querySelector(".sub-heading");
var titleElement = title.getContext("2d");
titleElement.font = "2rem Arial";
titleElement.fillStyle = "blue";
titleElement.textAlign = "start";
titleElement.fillText("Where you can write any of your", 510, 500);

