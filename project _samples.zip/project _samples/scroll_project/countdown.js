const months = [
    "January",
    "February", 
    "March",
    "April",
    "May",
    "June", 
    "July",
    "August", 
    "September",
    "October", 
    "November", 
    "December"
    ]
    
    const weekdays = [
    "Sunday",
    "Monday", 
    "Tuesday", 
    "Wednesday", 
    "Thursday", 
    "Friday", 
    "Saturday"]

let giveaway = document.querySelector(".giveaway");
let deadline = document.querySelector(".deadline");
let deadlineHeading = document.querySelectorAll(".deadline-format h4");
     
let futureDate = new Date(2022, 8, 16, 20, 56, 00);

let minutes = futureDate.getMinutes();
let seconds = futureDate.getHours();
let hour = futureDate.getHours();
let day = futureDate.getDay();
let year = futureDate.getFullYear();
let month = futureDate.getMonth();

month = months[month];

day = weekdays[day];

let futureTime = futureDate.getTime();

giveaway.innerHTML = `Our countdown begins on ${year}, ${month}, ${day}, at ${hour}: ${minutes} pm`

function remainingTime(){
let currentTime = new Date().getTime();

let timeDifference = futureTime-currentTime
console.log(timeDifference)


// values in ms

let oneDay = 24*60*60*1000;
let oneHour = 60*60*1000;
let oneMinute = 60*1000;


let day = timeDifference / oneDay;
day = Math.floor(day);

let hour = Math.floor((timeDifference % oneDay)/oneHour);
let minute = Math.floor((timeDifference% oneHour)/oneMinute);
let second = Math.floor((timeDifference% oneMinute)/ 1000);
console.log(second);


let values = [day, hour, minute, second];

function format(index){
if(index < 10){
return (index = `0${index}`);
}
else{
return index
}
}

deadlineHeading.forEach((hugeFormat, index)=> {

  hugeFormat.innerHTML = format(values[index]);

})


if(timeDifference < 0){
  giveaway.innerHTML = "Sorry , the offer has expired";
}









}
remainingTime();


let countdown = setInterval(remainingTime, 1000);


const aboutUs = document.querySelector(".about");
const btn = document.querySelectorAll(".tab-btn");
const content = document.querySelectorAll(".content");


aboutUs.addEventListener("click", function(e){
let id = e.target.dataset.id;
console.log(id);

if(id){
  btn.forEach((btn)=> {
    btn.addEventListener("click", function(){
      btn.classList.remove("active");
      e.target.classList.add("active");

      content.forEach(((eachContent)=> {
        eachContent.classList.remove("active");
      }))

      let elements = document.getElementById(id);
      elements.classList.add("active");
    })
  })
}
})