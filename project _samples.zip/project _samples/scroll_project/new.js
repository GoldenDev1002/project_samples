


const  tab_btn = document.querySelectorAll(".tab_btn");
const about = document.querySelector("#about");
const content = document.querySelectorAll(".content");

//adding the event listener to the  parent articl about 
/*about.addEventListener("click", function(e){
   // console.log(e.target);  //the target property returns the elemnet that triggered the events// as the about elemen is clicked , the article element that was used for it will show
let id = e.target.dataset.id;

if(id)// if id exists or in't undefined
//the class active should be removed from all the buttons because once the button is clicked the actual active class is added to another element

//remove activ from other buttons when one button is  clicked

btns.forEach(function(btn){
    btn.classList.remove("active");
    //add the active class to a button that is clicked;
    e.target.classList.add("active");

    //remove the class of active form all the contents to hide the other articles and use the dattset is to target the specific contnet with the corresponding id selector

    //hide the other articles to display the one that has the matching id selector
    articles.forEach(function(article){
        article.classList.remove("active");
        
    })

  //to display the content with the matching ids goals, vision, history 

  const element = document.getElementById(id);
  //then add a class of active to id itself
  element.classList.add("active");


  //the event target returns what you clicked on  // e.target
})
}) */


about.addEventListener("click", function(e){

    let id = e.target.dataset.id;
    console.log(id);

})