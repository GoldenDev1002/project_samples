// get the date

const date = document.getElementById("date");
date.innerHTML = new Date().getFullYear();

// close links

const navToggle = document.querySelector(".nav-toggle");
const linksContainer = document.querySelector(".links-container"); //parent
const links = document.querySelector(".links"); //child

navToggle.addEventListener("click", function(){
    let linksContainerHeight = linksContainer.getBoundingClientRect().height;// getBoundingClientRect() returns an object with top, left, bottom, right, x, y,width and heighto
    let linsHeight = links.getBoundingClientRect().height;

    if(linksContainerHeight === 0){
        linksContainer.style.height = `${linsHeight}px`
    }
    else{
        linksContainer.style.height = 0;
    }


   
})


let navbar = document.getElementById('nav');
let topLink = document.querySelector(".top-link");

//scroll event
window.addEventListener("scroll", function(){
const scrollHeight = window.pageYOffset
console.log(scrollHeight) //pageYOffset is a read-only window property that returns the number of pixels that the document has been scrolled vertically
const navHeight = navbar.getBoundingClientRect().height;

//if this value is bigger than the height of the navbar then add a specific class -> fixed-nav to our navbar
if(scrollHeight > navHeight){
    navbar.classList.add("fixed-nav");
}
else{
    navbar.classList.remove("fixed-nav");
}

//to diaplay the top-link button after 500px was rolled from the screen
if(scrollHeight > 500){
    topLink.classList.add("show-link")
}
else{
    topLink.classList.remove("show-link")
}

})


/*navToggle.addEventListener("click", function(){

   // linksContainer.classList.toggle("show-links");// the show-links class have a height of 200px to add to the linksContainer
    //the problem with this setup is that as more links are added or removed to the navbar the height will remain the same it's meant to be dynamic

    //to create a dynamic navbar

    //element.getBoundingClientRect returns the size of an element and its position relative to its viewport
    let containerHeight = linksContainer.getBoundingClientRect().height;
    console.log(containerHeight);
    //by default the linksContainer height is 0 in the css and on line 21 because it needs to be hidden
    //the linksContainer div is wrapping the links ul , don't call the height of the links ul if the div wrapping it isn't present, the height won't be accurate
    //the links ul doesn't have a height specified in the css so it's easier to change its height dynamically by adding it to the linksContainer height
    let linkHeight = links.getBoundingClientRect().height;
    console.log(linkHeight) //height is 201 cu of the four nav links present inside the
   
    //the linksContainer is set to 0 by default , however it will work when the links is set to 0 -> what will work


    if(containerHeight === 0){
        //then i want to dynamically add height
        linksContainer.style.height = `${linkHeight}px`;
    }
    else{
        //if the links are open 
        linksContainer.style.height = 0;
    }
    
    //fixed navbar

    //check for a scroll event 
    window.addEventListener("scroll", function(){
        console.log(window.pageYOffset); //pageYOffset 
    })
})
*/