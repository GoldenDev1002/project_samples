let objScope = {

    radius: 1,
    diameeter: 2,
    cicleFunction(){
        console.log("Hey, I'm a circle");
    }
}

console.log(objScope);
objScope.cicleFunction();


function factoryF(){

    return{
    radius: 11,
    diameter: 310,
    factories(){
        console.log('factoryF is a function');
    }
    }
}

const new2 = factoryF();
console.log(new2.radius);

function Constructor1(radius, name) {

this.radius = radius;
this.name = name;
this.shape = function(){
    console.log("This is a circle");
}


}
let circle1 = new Constructor1("20m", "first");
console.log(circle1);

const personDetails = {
  details(){
      return `My name is ${this.name} ${this.age}`;
  }
}
let person3= {
    name: "John Smith",
    age: "18"
}

person3.color = "blue";
console.log(person3);

let d1 =personDetails.details.call(person3);
console.log(d1);


const mySubject = {

    subjectDetails(duration, food){
        return `My favourite subjects are ${this.science1} ${this.science2} I eat ${food} ,${duration} a day`
    }
}

let subjects = {
    science1: "Maths",
    science2: "Computer"
}

let s1 = mySubject.subjectDetails.call(subjects);
console.log(s1);

let s2 = mySubject.subjectDetails.apply(subjects, ['twice', 'food']);
console.log(s2)

//adding to properties

function One(side){
    
    side;
    displayFunction = function(){

    console.log('display Me')
    }
}

let number1 = new One(3);
number1.talk = "Hey";
console.log(number1);

let newOne = {

    side: 1,
    house(ln3, n4){
      return `Welcome to where I stay ${this.address} ${this.location} ${ln3} ${n4}`;
    }
}

let secondOne = {
    address : "4 Irepodun",
    location: "surulere"
}

let n1 = newOne.house.call(secondOne);
console.log(n1);


let n2 = newOne.house.apply(secondOne, ["Dubai", "laslas"])
console.log(n2);
secondOne.name = "Jenny";

console.log(secondOne);


function ObjCircle3(){

   this.house = function(){
      console.log("My house, my rules");
   }
}

let o2 = new ObjCircle3();
o2.location = "California";
o2['streetName'] = "4 Irepodun";
delete o2.location;

console.log(o2);

function Test(){
    this.first = 1;

    this.testFunction = function(){
        console.log("Testing");
    }
}

let t1 = new Test();

for( t in t1){
    console.log(t1);
    console.log(t1[t]);

    if(typeof t1[t] !== "function"){
        console.log( t1, t1[t]);
    }

}

const keys = Object.keys(t1);
console.log(keys);

//to check an existing property  aka enumeration




function Great2(){

this.number = "1"
this.function1 = function(){

  console.log("This is a function");  
}


}

let g2 = new Great2();

let phoneCode = "+234";
g2.location = "new Birmigham";
g2['houses'] = "my new house";
let location1 = "Nigheria";
g2[phoneCode] = location1
console.log(g2);
 for(g in g2){
     console.log(g2[g]);
     console.log(g2);

     if(g2[g] !== "function"){
         console.log("this is it ", g2, g2[g]);
     }
 }



//abstraction


function circle3() {


    this.radius = radius;

    let defaultLocation = { // we want to hide this
        x: 1,
        y: 1
    };

   let optimumLocation = function(factor){

    }


    this.draw = function(){

        let x, y // these are closures which are varibles that are accessible to an inner function , closures are the opp of scope 
        //x and y are closures to the draw function
       optimumLocation(0.1); // we also want to hide, // the this keyword will not be used here because we are using a closure
        defaultLocation;
        this.radius;
        console.log('draw');
        
    }

    // in a closure the radius and optimumLocation variables continue to stay in memory after the draw fucntion is executed, closures remain permanent in memory
    //scopes variables are temporary cuz they only work within a fucntion
}


function Triangle(side, ){
    this.side = side;

    let DefaultLocation = {
        x: 1,
        y: 1
    }

    let goals = "mY goals";

    let optimumLocation = function(number){

    }

    this.getDefaultFunction = function(){
        return DefaultLocation;
    }

    this.draw = function(){
        console.log("Draw");
    }

    this.innerTraingle = function(){
        DefaultLocation;
        optimumLocation(0.1); //closures
    }

    Object.defineProperty(this, 'DefaultLocation',
    
    {
        
        get: function(){
        return DefaultLocation;
    },

    set: function(value){
        if(!value.x || !value.y) 
        throw new Error('invalid location');

        DefaultLocation =value;


    }



},


    
    
    )
}


let u1 = new Triangle();
u1.draw();

//u1.DefaultLocation = 1;




const studentDetails = {
    
    
    lastName: "Chikam",
    message: "Hi",
    
    
    get lastNames(){
        return this.lastName
    }
      
      
  }
  
  console.log(studentDetails.lastNames);



  let greatNess = {
      church: "Mountain OF fIRE",
      street: "4 Irepodun Avenue",

      get churchLocations(){
          return this.church
      },

      set newStreet(streetName){


          this.street = streetName;

      }
  }

  console.log(greatNess.church);



console.log("Hi");


const stopwatch = {

duration: "1000s",
reset : function(){

},

start:function(){

}, 

stop: function(){

},


}

//getters and setters

function practiceObj() {

    this.name= "Jenny Emenike",

    this.age ="21",

   this.color="blue",

    Object.defineProperty(this, "color", {

   get newLocation(){
       return this.age;
   },

   set: function(color1){
       if(color1 !== "red")

       throw new Error("Invalid color");
     color = color1;
     return color;
   }
}

    )
}

let p1 = new practiceObj();
p1.color = "blue";

console.log(p1.name);

