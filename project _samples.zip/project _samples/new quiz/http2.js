let stocks = {
    fruits : ["strawberry", "mango", "banana"],
    liquid : ["water", "ice"],
    holder: ["cone", "cup", "stick"],
    toppings : ["chocolate", "vanilla", "avocado"]
}


/*let order = (time)=> {
return new Promise((resolve, reject)=> {
setTimeout(()=> {
    resolve(console.log(`order has stated prepare the ${stocks.fruits[0]} and ${stocks.fruits[1]}`))
}, time)
})
}

async function kitchen(){
    console.log("A")
    console.log("B")
    console.log("C")
    await order(3000);
    console.log("D")
    console.log("E")

}

kitchen();
console.log("continue the process")
console.log("continue the process 2")
console.log("continue the process 3")

*/

let is_shop_open = true;

let new_order= (time, orders)=> {
    return new Promise((resolve, reject) => {
        if(is_shop_open){
        setTimeout(()=>{
         resolve(orders)
        }, time)
    }else{
         reject(console.log(`we're out of stock`))
    }
    })

}
 /*new_order(1200, console.log(`add ${stocks.liquid[0]} and ${stocks.liquid[1]}`))
 .then(()=> {
    return new_order(1300, console.log(`add ${stocks.liquid[0]} and ${stocks.liquid[1]}`))
 })
 .then(()=> {
    return new_order(1400, console.log(`add ${stocks.holder[0]} and ${stocks.holder[1]}`))
 })
 .then(()=>{
    return new_order(1500, console.log(`add ${stocks.toppings[0]} and ${stocks.toppings[1]}`))
 })

 .catch(()=> {
    console.log("order has been rejected")
 })

 .finally(()=> {
    console.log("the shop has been closed");
 })*/


 
async function kitchen(){

try{

await new_order(1000, console.log(`cut the fruit ${stocks.fruits[0]} and ${stocks.fruits[1]}`));
await new_order(1200, console.log(`add ${stocks.liquid[0]} and ${stocks.liquid[1]} to the container`));
await new_order(1300, console.log(`add ${stocks.holder[0]} and ${stocks.holder[1]} to the store`));
await new_order(1400, console.log(`add ${stocks.toppings[0]} and ${stocks.toppings[1]} to the store`));


}
catch{

console.log("order declined")
}
finally{
    console.log("the shop has been closed")

}


}

kitchen();
//async and await chains promises in a much more readable way
//async stores all the sync code in a function and await chains promises

/*fetch('https://jsonplaceholder.typicode.com/todos') // the fetch api works when the ourcome of a promise is succesful or if the link to the resource is correct or incorrect , thereby executing the .then method
  // the fetch api fails when there is an error fetching the resource or when the promise has an error , ex: if we are offline or network issue
.then(response => {
    console.log('resolved', response)
return response.json() //gets us the response data and parses it just like the JSON.parse, storing in a variable is a bad idea because response.json() returns a promise 

})
//in order to have access to the parsed data as the promise is successful use .then method and chain the promise 
.then((data)=> {
console.log(data)
})

  .catch(err=> {
  console.log('rejected', err)
  }) */

//fetch apis

fetch('https://jsonplaceholder.typicode.com/todos')
.then(newResponse => {
    console.log("this is the new response", newResponse)
  return newResponse.json();
})
.then((data)=> {
console.log(data);
})
.catch((err)=> {
    console.log("there is an error in the api", err);
})


//async and await 

const getTodos =  async() => {
//async return a promise no matter the data that's input into the function
}


//oopp

let user = {
    name: "Jenny",
    email: "emenikejenny2001",
    login(){
        console.log(this.email, "has logged in")
    }
    ,
    logout(){
        console.log(this.email, "has logged out")
    }
}

console.log(user.name);
console.log(user.email);

//object literals 
let user2 = {
    names: "Jenny Emenike", 
    age : 21,
    login(){
        console.log(user2.names , "has logged in")
    },
    logout(){
      console.log(user2.names, "has logged out");
    }
}

console.log(user2.login());
console.log(user2.logout());

user.age = 33;
console.log(user.age)



let phoneCode = {
    america : "+1",
    uk: "+44",
    nigeria: "+234",
    nigerianLine(){
        return this.nigeria + " this is nigerian line"
    }
}

console.log(phoneCode.nigerianLine());


// add properties to an object 
phoneCode.uae = "+971";
phoneCode.uk = "+44";
phoneCode.germany = "+233"

function Human(age, name){
    this.age = age;
    this.name = name;
}

let human1 = new Human(21, "jenny Emenikle");
let human2 = new Human(22, "jason statham");

console.log(human1);
console.log(human2);

//private property and method

human1.nationality = "nigerian";
console.log(human1.nationality)
human1.bio = function(){
    console.log("Jenny is a " + this.nationality);
}
console.log(human1.bio())

//classes 

class User {
constructor(name, email){
    this.name = name;
    this.email = email;
    this.score = 0;
}
logOut(){
     this.name+ " is logged out"
     return this

}
logIn(){
     this.name+ " is logged in"
     return this
}
updateScore(){
    this.score++
    console.log(this.email + "the user score is " + this.score);
    //whenenver a method is displayed on the console , it returns undefined but to reverse that the instance  of the object which is 'this' should be displayed
    return this
}
}


var firstUser = new User('Jenny Emenike', 'emenikejenny2001@gmail.com')
let secondUser = new User('Maria Staples', 'mariastaples@gmail.com')

firstUser.logIn().updateScore().updateScore().logOut();

