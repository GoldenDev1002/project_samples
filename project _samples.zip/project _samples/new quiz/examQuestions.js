function ExamQuestion(quest){
this.questions = quest;
this.index = 0;
}

ExamQuestion.prototype.displayQuestion = function(){

  return  this.questions;
}

ExamQuestion.prototype.changeQuestion = function(){
  let index = 1;
}

ExamQuestion.prototype.totalLength = function(){
  return this.questions.length;
}