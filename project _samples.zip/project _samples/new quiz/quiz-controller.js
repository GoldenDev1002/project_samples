// we need what is displayed to te user
//we have our modules in which data is stored and
//we need a controller

function Quiz(quest) {
    this.score = 0;
    this.questions = quest; //representing the questionsArray 
    this.questionIndex = 0;
}

Quiz.prototype.getQuestionIndex = function () {
    return this.questions[this.questionIndex] //returns the first element of the array which is an object
}

Quiz.prototype.isEnded = function () {
    return this.questions.length === this.questionIndex; //that means 5 = 0 is false
}
