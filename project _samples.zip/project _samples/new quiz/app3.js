let questionArray = [
    
]

function timing(){
    let time = 15;
    let timeHolder = document.getElementById("time");

    let questionTime = setInterval(function(){
        timeHolder.innerHTML = time-- + "s";
        timeHolder.style.color = "green";
        if(time <= 5){
            timeHolder.style.color = "red";
            if(time === 1){
                clearInterval(questionTime);
                QandA2();
            }
        }

    
    }, 2000)
}


function registration(){
    let clickBtn = document.getElementById("click");
    let cardContainer = document.querySelector(".card-container");
    clickBtn.onclick = function(){
        
    cardContainer.classList.add("cardHover");
    let nameID = document.getElementById("name");
    let nameHolder = document.querySelector(".names");
    nameHolder.innerHTML = nameID.value;
    
    }
    }


registration();