function Options(options, correctAnswer){//Option not Options
    this.options = options;
    this.correctAnswer = correctAnswer;
    this.index = 0;
}

Options.prototype.displayOption = function (){// OPTION NOT OPTIONS
    return this.options;
    

}
//we use a function to display the property of a constructor instead of retrieving it directly because the property can change


Options.prototype.isAnswer = function(choiceOption){

  return this.correctAnswer === choiceOption
   //the output will be returned to  the caller of the function

    //return stmt stops the flow of the code, return stmt as the last stmt of th function
}


