function ExamQuestions(questions, options, answers){
    this.questions = questions;
    this.options = options;
    this.answers = answers;
}

ExamQuestions.prototype.correctAnswer = function(ans){
    return this.answers === ans
}