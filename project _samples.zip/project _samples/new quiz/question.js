//question module

function Question(text, choices, answer/*these are paarmeters*/ ){  //constructor functions are used to create multiple instances
    this.text = text;    //we are creating the property of the object ahead of time and initializing the function  
    //text represents the questions 
    this.choices = choices; // choices reperesents the options in ana array
    this.answer = answer;
}

//explain this ocnstructor function


//in oop don't jam-pack all your work in one file, so that errors will be traced, your code  will be neat and to make modifications easier
//a constructor function is used to create multiple instances aka object that has access to the same properties and methods. Parameters are passed into the constructor function
//Parameters are variables passed to a constructor fucntion
//parameters are variables passed to a function
//arguments are values paddes after th function is invoked
//the parameter are acting as the values of the property also initalizing the property from line 2 - 4 since the properties are not hard-coded;
//when the object is created, arguments are passed to the instance of the constructor
//parameeters must be set in variable form so that it can be reused not in string form
//parameters are used to initialize the property
//properties are variables



// let ageOption = [1, 2,3,4,5,6]
// let quest = new Question("What is your age", ageOption, 5); //arrays store data of the same data type or different data types

//every function that you want to give public access specifier create it on the prototype of the constrcutor not within the body of a constructor function

//examples 

Question.prototype.correctAnswer = function(choice){
    return choice === this.answer //this shows that the current object that will be created from the Question constructor will have access to the public method correctAnswer();
}

// //creating the public constructor function outside the scope of the constructor function
// 1 it's th eprofessional method
//in case of inheritance the methods will be accessible since it's present on the proptotype of the constructor


//app.js is the parent for questions.js and quiz-