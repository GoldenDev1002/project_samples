function Options(options, correctChoice){
    this.options = options;
    this.correctChoice = correctChoice;
}

Options.prototype.displayOption = function(){
    return this.options;
}

Options.prototype.correctAnswer = function(answer){
    return this.correctChoice === answer
}