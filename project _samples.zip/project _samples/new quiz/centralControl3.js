function centralControl(questions){
    this.questions = questions;
    this.index = 0;
    this.score = 0;
}


centralControl.prototype.displayQuestion = function(){
    return this.questions[this.index];
}

centralControl.prototype.correctChoiceChecker = function(correctChoices){
    if(this.displayQuestion().correctAnswer(correctChoices)){

     this.score+=1;
    }
    this.index +=1;
}

centralControl.prototype.isEnded = function(){
    return this.questions.length === this.index;
}