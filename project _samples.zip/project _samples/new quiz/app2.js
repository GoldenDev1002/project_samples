let question = [
    new ExamQuestion("Who is the president of NIgeria",["Buhari", "Sanni Abacha", "Peter Obi", "polo"],"Buhari" ),
    new ExamQuestion("What is the capital of Nigeria",["Lagos", "Abuja", "Port Harcourt", "Kwarra"], "Abuja" ),
    new ExamQuestion("Who will be the next president of Nigeria", ["Buhari", "Sanni Abacha", "Peter Obi", "polo"], "Peter Obi")
]


let central = new CentralControl(question); //parameters are variables and aruguments are values

function QuestionandAnswer(){


if(central.isEnded()){ //0 is compared to 3 aka false
 
showScore();


}
else{
   let questionTag =  document.getElementById("question");
   questionTag.innerHTML = central.displayQuestion().question; //showing the questions from the question property

   //display answer

   let choice = central.displayQuestion().option; 
   choice.map((e, index)=>{
    
    let span = document.getElementById("choice"+ index); //referencing the span tag not  the button
    span.innerHTML = e;

    checkUserOption("btn"+ index, e); 
   

    
   }
   )
  //after selecting the options, the progress function will execute
  progress();
}



}

QuestionandAnswer();


function checkUserOption(id /*to track the button id*/, userChoice /*referring to the user's choice*/){
    let choiceBtn = document.getElementById(id); //represents the button but the ID parameter will be invoked inside the button tag

    choiceBtn.onclick = function(){

    central.checkOption(userChoice);
    QuestionandAnswer();// invoking the function here so that the next set of question and options will appear


    }
    


}


function showScore(){
let score = "<h1>Score: </h1>";
let totalQuestions = question.length
score+= "<h2 id='score'>Your score: "+central.score+" out of "+ totalQuestions+" questions correctly"+ "</h2>"; //don't use  a variable in double quotes inside double quotes will give an eror because the js engine thinks that it's the end of a atringS
let quiz = document.getElementById('quiz');
quiz.innerHTML = score;
}




function progress(){

//to change the question

let currentNumber = central.index + 1; //there's no need to create a public method for the index variable
let totalQuestions = question.length
let progress = document.getElementById("progress");
progress.innerHTML = "Question" + currentNumber + "of " +totalQuestions;






}

function timing(){
    let time = 15;
    let timeHolder = document.getElementById("time");

    let questionTime = setInterval(function(){
        timeHolder.innerHTML = time-- + "s";
        timeHolder.style.color = "green";
        if(time <= 5){
            timeHolder.style.color = "red";
            if(time === 1){
                clearInterval(questionTime);
                QuestionandAnswer();
            }
        }

    
    }, 2000)
}

function backSide(){
    
    let cardContainer = document.querySelector(".card-container");
let nice = cardContainer.classList.add("cardHover");
nice = true;
    
if(nice== true){

   timing();
}
}


function registration(){

   //let users_name = prompt("What is your name?", "Yes")
    let clickBtn = document.getElementById("submit");
    let cardContainer = document.querySelector(".card-container");
    clickBtn.onclick = function(){
     
        
       
        let nameID = document.getElementById("name");
        let emailID = document.getElementById("email");
        let nameHolder = document.querySelector(".names");

        if(nameID.value.length != 0 && emailID.value.length != 0){

            let confrimButton= confirm("Are you ready for your test?");
       
       
     if(confrimButton == true){
        nameHolder.innerHTML = nameID.value;
      backSide();
     }
     else{
        alert("Sorry, you can't participate in the test")
        cardContainer.classList.remove("cardHover");
     }
        
        }
        else{
            alert("Input your details");
        }
    
    }
}


registration();



//my task adda functionality
//before the quiz starts , the user should register his name the name should appear at the end of the score,
//add a timer to each question once the time for each question elapses , the next question shows min of 15s
//submit before monday



function buttonFunction(){
    let btn= document.getElementById("click");
    let btn2 = document.getElementById("click2");

    btn.onclick = function(){
        btn.dataset.isClicked = true;
    }
   

    if(btn.dataset.isClicked == true){
        console.log("Hi");
    }
    btn2.onclick = function(){
        console.log(btn.dataset.isClicked? "Yes , it's clicked" : "Nope");
        let t= 10
        let colorChange = setInterval(function(){
        btn2.style.backgroundColor = "blue";
        let m = t-- ;
        console.log(m)
        if(m ==5){
            clearInterval(colorChange);
            btn2.style.backgroundColor = "pink";
        }
           
        }, 1000)

       

    }
    btn.clicked  = true;
    if(btn.clicked  = true ){
        console.log("true");
    }
    else{
        console.log("false");
    }
}

//prompt has 2 buttons ok and cancel


buttonFunction()











/*let answer_array = [
    new Options(["Buhari", "Sanni Abacha", "Peter Obi", "polo"], "Buhari"),  
    new Options(["Lagos", "Abuja", "Port Harcourt", "Kwarra"], "Abuja"),
    new Options(["Buhari", "Sanni Abacha", "Peter Obi", "polo"], "Peter Obi"),
]





let index = 0;  //closure -> make sure the index is declared outside the function
//where loop can't iterate to give the value required, use closures







const showQuestions = function(){

// let singleQuestion = question[index].displayQuestion();
// console.log(singleQuestion);

let dis_question = document.getElementById("question");
//we want to remove each question as its clicked to reduce its array length

    const quest = question[index]; //shift();
     console.log(quest.displayQuestion())//removes the first element of the array, 2 will remain

    
    dis_question.innerHTML = quest.displayQuestion();

    let progress = document.getElementById("progress");
    let lengths = question.length;
    
    
    if( index < lengths){
        index+=1;
        progress.innerHTML = `question ${index} of ${lengths}`
    }
    else{
        index = 0;
        progress.innerHTML = `question ${index} of ${lengths}`
    }
    

  




console.log(index);
  //using closures here, the index becomes 1 after the first invocation, then the function dies and the variable is stored in the memory 
//in the system then when the function gets incoked again the system will remember the last value of that stored variable





}



//
let object_index = 0;
let score = 0;
const showOptions  = function(){
    let answerLength = answer_array.length;
   

    let object = answer_array[object_index]; //removes the first ELEMENT AND LEAVES the remaining elements
    let opt = object.displayOption(); // displays the first array of the first element 

    opt.map((e, index)=>{
        //map has 3 parameters, d element which is the necssary, index and the object or array itself
        let button = document.getElementById("btn"+ index);  //when u concatenate string and number it will become string with othe roperators it will become NAN
        button.innerHTML = e; 
        button.addEventListener("click", function(){ 
             //eventListener will take 2 parameters, an event and a callback function
            let choice = e; //the choice is stored in a variable
       if(object_index <  answerLength)  {  
           
         let curChoice = object.isAnswer(choice); //takes an arugument and it's compared
         if(curChoice == true){

             
            score+=1;
            console.log(score);
         }

         
         object_index += 1;
           
         console.log(curChoice); 
        
        
        }




         // the answer options is to put the correct and wrong answer

          showQuestions();
          
          showQuestions();

          showQuestions();
         
      showOptions();
        question_ended();
       
      
        })
        console.log(button);
       
       
    })

  
    


}
// 


showOptions();

function question_ended(){
   
    console.log("hi");
  
  let new_index = object_index + 1 ;//3
 
    if(new_index === answer_array.length){

        let score_section = document.getElementById("score");
        score_section.innerHTML = `You scored ${score} out of ${question.length} questions correctly`
        score_section.style.visibility = "visible";
        }
}


// function progress(){
//     let progress = document.getElementById("progress");

//     progress.innerHTML = `question ${index} of ${lengths}`
  
// }  //the console is printing the function afresh, not the varaiable..

*/