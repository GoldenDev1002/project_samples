function Answers(options){
    this.options = options;
}

Answers.prototype.correctOption = function(){
   return this.options;
}