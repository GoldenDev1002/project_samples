let questions = [
    new Question("Which one is an oop language", ["c", "c++", "java", "js", "python"], "js"), //creating instance of the Question constructor that will act as the object
    //therby making the array an array of objects
    new Question("What is MVC", ["model-view-controller", "view-model-controller", "mimn", "ilo"], "model-view controller")

]

var quiz = new Quiz(questions)// passing the questions array as the paarmeter to the Quiz constructor which is caalled question

function populated(){
    if(quiz.isEnded())// checking if the isEnded public function is present in the quiz constructor, the if statement returns a boolean (t/f)
{
    showScore();
}
else{
    var element = document.getElementById('question');
    element.innerHTML = quiz.getQuestionIndex().text;  // the operator precedence starts from left to right

  //ignore 
    //for the getQuestionIndex() to have acces to the text propertyu
    Quiz.prototype.getQuestionIndex = function (){
        return this.question[this.questionIndex] //returns the first element of the array which is an object and it can access the text property 
        //through the questions Array
    }
    
     //the getQuestionIndex() is an object having access to the text property
}
let choices = quiz.getQuestionIndex().choices;
for(let i =0; i < choices.length; i++ ){
    let element = document.getElementById("choices");
    element.innerHTML = choices[i];
    //guess("btn + i", choices)
}
}

