
//sending a rewuest from the browser
/*const request = new XMLHttpRequest(); // new keyword creates an instance of object with constructor function & XMLHTTPRequest represents an older format that was used before json
//the request object can work with xml, json or any data

request.addEventListener('readystatechange', function(){ //readystatechange means the request is going through different phases
console.log(request, request.readyState ) //the  state that the request is in -> which are 4 requests

  if(request2.readyState === 4 && request2.status === 200){
        console.log(request2.responseText);
    }
    else if(request2.readyState === 4){
        console.log('the data couldn\'t be found');
    }
})

//prepsring the request 
request.open('GET', 'https://jsonplaceholder.typicode.com/todos/1' ) //.open takes 2 parameters , the type of request and the endpoint where we want to make the request to where we want tot get the data from 
request.send(); */

/*const getTodos = (callback) => {
const request2 = new XMLHttpRequest();
request2.open('GET', 'https://jsonplaceholder.typicode.com/todos/1');
request2.addEventListener('readystatechange', function(){
    //console.log(request2, request2.readyState);
    if(request2.readyState === 4 && request2.status === 200){
       callback(undefined, request2.responseText);
    }
    else if(request2.readyState=== 4){
        callback('error here',undefined);
    }
    
})
request2.send(); 

}

//getTodos();

getTodos(
    

    (err, data)=> { //by cponvention error comes before data in networking
    console.log('fired');
    console.log(err, data); 

} ) 
*/
const requestOption = ( callback) => {
const newRequest2 = new XMLHttpRequest;
newRequest2.open('GET', 'todo.json');
newRequest2.addEventListener('readystatechange', function(){
    console.log(newRequest2, newRequest2.readyState);
    if(newRequest2.readyState === 4 && newRequest2.status === 200){
        const data = JSON.parse(newRequest2.responseText) //CONVERTING THE STRING jsoN FROM TODO TO A REAL JAVSCRIPT OBJECT USING PARSE
        callback(undefined, data)
    }
    else if(newRequest2.readyState === 4){
     callback("Incorrect link", undefined);
    }
})
newRequest2.send();

}
requestOption( (err, data)=> {
    console.log("error second to one")
    console.log(err, data)
})


let stocks = {
    fruits : ["strawberry", "mango", "banana"],
    liquid : ["water", "ice"],
    holder: ["cone", "cup", "stick"],
    toppings : ["chocolate", "vanilla", "avocado"]
}
console.log(stocks.fruits);
let ordered = ()=> {
    setTimeout(()=> {
        let output = ""
      output = `<li> ${stocks.fruits.splice(0, 1)}</li>`
      return output;
    }, 3000)
     
}
 function one(call_order){
    console.log("order 1 has finished, call order 2");
    call_order();

 }

 one(ordered);



 let ordered2 = (time, call_production)=> {
    console.log("order 2 has finished, start the production")
    setTimeout(()=> {
        console.log(`order 2 has finished, start production, ${stocks.fruits[0]}` )
    }, time)

    call_production()
 }

 let production2 = ()=> {

console.log("production has started");
 }


 ordered2(2000, production2)







 /*let order = (call_production, fruit_stocks)=> {
    console.log("order has nbeen placed");

    setTimeout(()=> {
        console.log(`${stocks.fruits[fruit_stocks]}`)
          }, 2000)
    
     call_production();
 }

 let production = ()=> {
    setTimeout(()=> {
    console.log("production has been placed");

    setTimeout(()=> {
        console.log("the fruit has been chopped");

        setTimeout(()=>{
            console.log(`${stocks.liquid[0]} and ${stocks.liquid[1]} were added`);

            setTimeout(()=> {
           console.log("the machine has started");

           setTimeout(()=> {
     console.log(`you can select either ${stocks.toppings[0]} or ${stocks.toppings[1]} or ${stocks.toppings[2]}`);
           }, 2000)
            }, 1000)
        }, 1000)


       
    }, 2000)
},1000)
 }
  
 production();

 order(production, 0)
*/

/*let order = (call_production, fruit_stocks)=> {

     setTimeout(()=> {
        console.log(`${stocks.fruits[fruit_stocks]}`)
     }, 3000)
    call_production();

}


let production = ()=> {

    console.log("production has started");

    setTimeout(()=> {
        console.log("cut the fruit")

        setTimeout(()=> {
            console.log(`${stocks.liquid[0]} and ${stocks.liquid[1]}`)

            setTimeout(()=> {
                console.log("start the machine");

                setTimeout(()=> {
                    console.log(`please choose between ${stocks.holder[0]} or ${stocks.holder[1]} or ${stocks.holder[2]}`);
                    
                    setTimeout(()=> {
                        console.log(`please select your favourite toppings ${stocks.toppings[0]}, ${stocks.toppings[1]}, ${stocks.toppings[2]}`)
                    }, 1000)
                }, 2000)
            }, 1000)
        }, 2000)
    }, 2000)
} */


/*let is_shop_open = true; // as the shop is open, we r serving ice cream
let order = (time, work) => { //relatinoship between time and work

    return new Promise((resolve, reject)=> {
        
        if(is_shop_open){
            setTimeout(()=> {
            resolve(work)//if the shop is open, then the ice cream order is placed and preparation starts
            }, time)
        }
        else{
            reject(console.log("The store was closed"));
        }

    })

}


order(2000, console.log( `${stocks.fruits[0]} was picked`)); */


/*let is_shop_open = false;
let order = (time, work) => {
     
    return new Promise((resolve, reject) => {
      
        if(is_shop_open){
            setTimeout(()=> {
            resolve(work)
            }, time)
        }
        else{
            reject(console.log("We're sorry but the order isn't available"))
        }

    })
}


order(2000, console.log(`${stocks.fruits[2]} were added`))


//promise chaining
//after resolve return each process using then kyword
.then(()=> {

    return order(1000, console.log("production has started"))
})

.then(()=> {

    return order(2000, console.log("start the machine"))
})

.then(()=> {
    return order(3000, console.log(` choose between ${stocks.holder[0]} or ${stocks.holder[1]} or ${stocks.holder[2]}`))
})

.then(()=> {
    return order(2000, console.log("Serve ice cream"));
})


//error handler
.catch(()=> {
console.log("our shop is closed");
})



//finally handler
.finally(()=> {
    console.log("day ended, the shop has closed")
})
//order(production, 0)


async function order3(){
    try{
        await  abc//abc depend on a functionz
        console.log("hi abc");
    }
    catch(error){
  console.log("abc code runaway", error);
    }
    finally{
        console.log("run code anyways");
    }
}

order3();
*/

//say for instance , a chef collects an ice-cream order but forgets the toppings for that order, the chef goes back to the customer and collects the topping order
//while this is going on, other employees are doing their jobs 
/*let toppings_choice = () => {

    return new Promise((resolve, reject)=> {

        setTimeout(()=> {
            resolve(
            // asking the favourite toppings
            console.log("which toppping would you love?")
            )
        }, 3000)

    })

}


async function kitchen(){
    //  processs for making the ice cream
    console.log("A")
    console.log("B")
    console.log("C")
    // going outside the kitchen to collect toppings order , therefore halting the ice cream making process but allowing other employee activites like taking orders, cleaning tables to continue
    await toppings_choice()
    //after taking the order d and e begins to work
    console.log("D")
    console.log("e")

}

kitchen();



//processes outside the kitchen
console.log("cleaning dishes");
console.log("taking other peoples orders");
console.log("making deliveries");
*/

let new_toppings = ()=> {

    new Promise((resolve, reject)=> {
        setTimeout(()=> {
            resolve(console.log("which toppings do you like to have"));
        }, 3000)
    })
}




async function kitchen(){
    console.log("A")
    console.log("B")
    console.log("C")
     
    await new_toppings()
    console.log("D")
    console.log("E")
}


kitchen();

new_toppings();
console.log("handling profits and losses");
console.log("delaing with orders")





/*

let new_toppings2=()=> {
    return new Promise((resolve , reject)=> {
        setTimeout(()=> {
       resolve(console.log("select your favourite toppings"))
        }, 3000)
    
    })
  
}

async function ice_cream_process(){
    console.log("Allo");
    console.log("Bllo");
    console.log("Cllo");
    await new_toppings2();
    console.log("Dllo");
    console.log("Ello");
}

ice_cream_process();
console.log("the ice cream truck");


*/


let shop_open = false;
let new_order = (time, work)=> {

return new Promise((resolve, reject)=> {
    if(shop_open){

        setTimeout(()=>{

            resolve(work);
        
        }, time)

    }else{
        reject(console.log("sorry your order has been rejected"))
    }

}
   
)
}

new_order(1000, console.log(`you can choose between${stocks.fruits[0]} and ${stocks.fruits[1]} and ${stocks.fruits[2]}`))

.then(()=> {
    return new_order(2000, console.log(`you can add ${stocks.liquid[0]} and ${stocks.liquid[1]}`))
})


.then(()=> {
    return new_order(2500, console.log("start the machine"))
})


.then(()=>{
    return new_order(3000, console.log(`select container between ${stocks.holder[0]} and ${stocks.holder[1]} and ${stocks.holder[2]}`))
})

.then(()=>{
    return new_order(3500, console.log(`select toppings between ${stocks.toppings[0]} and ${stocks.toppings[1]}`))
})

.then(()=> {
    return new_order(4000, console.log("seve ice cream"));
})

.catch(()=> {
    console.log("sorry we're out of ice cream")
})

.finally(()=> {
    console.log("We've closed our shop");

})




function time(ms){
    return new Promise((resolve, reject)=> {
        if(shop_open){
            setTimeout(resolve, ms)
        }else{
            reject(console.log("the shop is closed"));
        }
    })
}


async function new_kitchen2(){


    try{

        await time(2000)
        console.log("cut the fruit");

        await time(1000)
        console.log(`${stocks.fruits[0]} was added and ${stocks.fruits[1]}`);

        await time(2000)
        console.log(`${stocks.liquid[0]} was added and ${stocks.liquid[1]}`);

        await time(1000)
        console.log("the machine started");

        await time(1000)
        console.log(`you can chooose between ${stocks.holder[0]} or ${stocks.holder[1]} or ${stocks.holder[2]}`);

        await time(1000)
        console.log(`you can chooose between ${stocks.toppings[0]} or ${stocks.toppings[1]} `);

        await time(2000)
        console.log("serve ice cream");

        

    
    }

    catch(error){
  console.log("customer closed", error)
    }

    finally{
    console.log("day ended shop is closed p2")
    }
}

new_kitchen2();