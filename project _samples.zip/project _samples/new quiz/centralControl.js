function CentralControl (questionArray){
this.questionArray = questionArray; //question Array will be passed here
this.score = 0;
this.index = 0;

}
//seperation of concern aka modules

CentralControl.prototype.displayQuestion = function(){//creating a public method makes it accessible and available for inheritance
    return this.questionArray[this.index]; //returns an object of the ExamQuestion
    //return type means the type of value or data type a function is returning
}

//when the user clicks , the function stores the correct answer and increments the question index and answer index 

CentralControl.prototype.checkOption = function(userChoice){
    //storing the choice of the user when the button is clicked
     //this is used because displayQuestion belongs to the centralcontrol constructor
    if(this.displayQuestion().isCorrectAnswer(userChoice)){ // returns an object initalized using ExamQuestion constructor having access to the correctAnswer method  with a
        //which returns True or False
      
        this.score += 1;

    }
    
    this.index += 1;
}

CentralControl.prototype.isEnded = function(){
    return this.questionArray.length === this.index;
}

