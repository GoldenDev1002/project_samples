function Question(text, choices, answer){
    this.text = text;
    this.choices = choices;
    this.answer = answer;
}
 
Question.prototype.isCorrectAnswer = function(choice){
    return choice === this.answer
}

function Quiz(quest){
    this.quest = quest;
    this.score = 0;
    this.questionIndex = 0;
}

Quiz.protoype.isEnded = function(){
    return this.questionIndex === this.quest.length
}

Quiz.prototype.getQuestionIndex = function () {
    return this.quest[this.questionIndex];
}

let questions = [
    new Question("Where is Nigeria Located", ["Africa","Asia", "Oceania", "Europe"], "Africa"),
    new Question("Where is UAE Located", ["Africa","Asia", "Oceania", "Middle East"], "Middle East"),
    new Question("Where is Japan Located", ["Africa","Asia", "Oceania", "Middle East"], "Asia"),
]

let quiz = new Quiz(questions);

if(quiz.isEnded()){
    showScore();
}
else{
    let choice = quiz.getQuestionIndex().choice;
    for(let i = 0; i < choice.length; i++){
     let element = document.getElementById("choice");
     element.innerHTML = choice[i];
    
    }
}