function ExamQuestion(question, option, correctAnswer){
this.question = question;
this.option = option;
this.correctAnswer = correctAnswer;
}



ExamQuestion.prototype.isCorrectAnswer = function(userChoice){
    return this.correctAnswer === userChoice;
}

//object literals are created for key-value pairs, whether arrays or payment_methods
//object literals are variables that hold multiple properties or collections of properties

//to create multiple instances or behaviours of multiple instances you can use either factory function or constructor function
//by default a js developer uses factory functions , which doesn't use this or new keywords to create instances unlike constructor function
//when instatiating the constructor uses the new keyord along with its name