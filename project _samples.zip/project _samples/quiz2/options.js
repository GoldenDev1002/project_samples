function Options(option, correctAnswer){
this.option = option;
this.correctAnswer = correctAnswer
}

Options.prototype.displayOption = function(){
  return this.option;
}

Options.prototype.isCorerct = function(ans){
  return this.correctAnswer === ans
}