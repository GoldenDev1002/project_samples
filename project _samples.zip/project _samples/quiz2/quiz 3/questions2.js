function Question(text, choices, answers) {
    this.text = text;
    this.choices = choices;
   this.answers = answers;

}

Question.prototype.isCorrect = function(correctAns){
    return this.answers === correctAns;
}