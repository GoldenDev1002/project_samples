function CentralControl(questionArray){
    this.questionArray = questionArray;
    this.index = 0;
    this.score = 0;
}

CentralControl.prototype.displayQuestion = function(){
    return this.questionArray[this.index];
}

CentralControl.prototype.CorrectAns = function(correctAnswer){
    if(this.displayQuestion.isCorrect(correctAnswer)){
        this.score++
    }
    this.index++
}

CentralControl.prototype.isEnded = function(){
    return this.questionArray.length === this.index;
}
