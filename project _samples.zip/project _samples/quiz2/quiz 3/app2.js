let QuestionArray = [
    new Question("Who is the first President of Nigeria", ["Buhari", "Abacha", "Obi", "Adua"], "Adua"),
    new Question("When did Nigeria gain its first independence",["1960", "1970", "1980", "1990"], "1960"),
    new Question("Who created the first airplane", ["The Wright Brothers", "Thomas Edison", "Abraham Lincoln", "The Wright Brothers"])
]

let central = new CentralControl(QuestionArray)
function QuestionAnswer(){
    if(central.isEnded()){
        showScore();
    }
    else{
        let questionHolder = document.getElementById("question");
        questionHolder.innerHTML = central.displayQuestion().text;

        let options = central.displayQuestion().choices;
        options.map((element, index)=> {
            let span = document.getElementById("choice"+ index);
            span.innerHTML = element;

            checkUserOption("btn"+index, element);
        })
    }
    progressBar();
}


function checkUserOption(id, userChoice){
    let button = document.getElementById(id);
    button.onclick = function(){
        central.CorrectAns(userChoice);
        QuestionAnswer();
    }


}


function showScore(){
    let score = "<h1> Score </h1>";
    let total = QuestionArray.length;
    score += "You scored"+ central.score +"out of"+ total+ "questions correctly";
    let quiz = document.getElementById("quiz");
    quiz.innerHTML = score;
}

function progressBar() {
    let progress =  document.getElementById("progress");
    let currentIndex = central.score;
    let totalQuestions = QuestionArray.length
    progress.innerHTML = currentIndex + "of"+ totalQuestions 
}

function registration(){

    let button = document.getElementById("click");
    let emailID = document.getElementById("email");
    let nameID = document.getElementById("name");
    let nameHolder = document.getElementById("name1");
    let card = document.querySelector(".card-container");
    button.onclick = function(){
        let confirmPrompt = confirm("Are you ready for the test?");
        if(confirmPrompt == true){
if(emailID.value.length != 0 && nameID.value.length != 0){
nameHolder.innerHTML= nameID.value 
    card.classList.add("cardHover");
    QuestionAnswer();
}
        }
    }
}

registration();