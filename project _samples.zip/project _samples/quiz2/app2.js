let questionArray = [
    new Questions("Who is the ex president of Nigeria?"),
    new Questions("Where is Nigeria located?"),
    new Questions("Who is the president of Nigeria?")
];

let answerArray = [
    new Options(["Buhari", "Sanni", "Obi", "Atiku"], "Atiku"),
    new Options(["Africa", "Asia", "Europe", "Middle East"], "Africa"),
    new Options(["Buhari", "Sanni", "Obi", "Atiku"], "Obi")
];


let question_index = 0;
const showQuestion = function(){
    let dis_question = document.getElementById("question");
    let lengths = questionArray.length;

    const firstQuestion = questionArray[question_index];
    console.log(firstQuestion)
    let eachQuestion = firstQuestion.displayQuestion();

    dis_question.innerHTML = eachQuestion;

    if(question_index < lengths){
        question_index+=1;
    }
    else{
        question_index = 0;
    }

  let progress = document.getElementById("progress");
  progress.innerHTML = `question ${question_index} of ${lengths}`


}

showQuestion();

function showOptions() {
    let firstOption = answerArray.shift();
    console.log(firstOption)
    let object = firstOption.displayOption();
    object.map((e, index)=> {
     let button = document.getElementById("btn" + index);
     button.innerHTML = e;
button.addEventListener("click", function(){
let choice = e;
console.log(choice);

let currentChoice = object.isCorrect(choice);
console.log(currentChoice)
})
showQuestion();
showOptions();
    
    })
}


showOptions();