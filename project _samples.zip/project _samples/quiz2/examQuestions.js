function Questions(question){
    this.question = question;

}

Questions.prototype.displayQuestion = function(){
    return this.question;
}