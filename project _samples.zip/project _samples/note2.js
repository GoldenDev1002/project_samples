const menu = document.getElementById("mobile-menu");
const menuLink = document.getElementById("navigation-links");
menu.addEventListener("click", function(){
    menu.classList.toggle('is-active');
    menuLink.classList.toggle('active');
})