let age = 20;
let salary = 30000;
let net_worth = 15000;

function employee(age, salary, net_worth) {
  return age + (salary - net_worth);
}

let employees = {
  age: 24,
  salary: 4000000,
  net_worth: 150000,
  getWage: function () {
    this.age - this.salary * this.net_worth;
  },
};

employees.getWage();

let circle = {
  radius: 1,
  location: {
    x: 1,
    y: 1,
  },
  draw: function () {
    console.log("Darw mw");
  },
};

circle.draw();
circle.radius;

//Factory

function createCircle(radius) {
  /*radius: radius*/ // if the key and object properties are the same then it will become radius,
  return {
    radius,

    draw: function () {
      console.log("Draw me");
    },
  };
}

const circles = createCircle(1);
circles.draw();

function anotherCircle(side) {
  return {
    side,
    drawing: function () {
      console.log("Im drawing a ball");
    },
  };
}

const circle1 = anotherCircle(2);
circle1.drawing();

function Circle2(radius) {
  this.radius = radius;

  this.newDrawing = function () {
    console.log("A new drawing book");
  };
}

const firstShape = new Circle2(23);
firstShape.newDrawing();

function factoryFunction(side1) {
  return {
    side1: side1,

    balls: function () {
      console.log("I'm drawing six tennis balls");
    },
  };
}

const factory1 = factoryFunction(3);
factory1.balls();

function Constructors(side2) {
  side2;
  this.pencils = function () {
    console.log("These are pencils used for writing");
  };
}

const writeups = new Constructors(2);
writeups.side2;

/*function methods*/

// calls a function with {}, no.of arguments

// writeups.call({}, 1,2,3,4)

const person = {
  fullName: function (age, student) {
    return (
      "My name is " +
      this.firstName +
      " " +
      this.lastName +
      ". " +
      "I'm " +
      age +
      " years " +
      student
    );
  },
};

let person1 = {
  firstName: "Jenny",
  lastName: "Emenike",
};

let names = person.fullName.call(person1);
console.log(names);

const person2 = {
  phoneDetails: function (city, time) {
    return (
      "I bought a " +
      this.phone +
      " at" +
      this.price +
      " " +
      "in" +
      city +
      " " +
      time
    );
  },
};

const phone = {
  phone: "Samsung Galaxy 23",
  price: "N50000",
};

const phone3 = {
  phone: "Iphone X",
  price: "150000",
};
let phones = person2.phoneDetails.call(phone);
console.log(phones);

let phoneDETAILS1 = person2.phoneDetails.apply(phone3, ["Dubai", "night"]);
console.log(phoneDETAILS1);

let phones4 = person.fullName.apply(person1, ["21", "student"]);
console.log(phones4);

//constructors referencwe the functions that were used to create an object
/*ex: New String() but instead we use "", ' ', ``
New Boolean() but instead we use true, false


*/

//primitive types

let x = 10;
let y = x; // these values are independent of each other

x = 20;
console.log(x);
console.log(y);

//reference types

let a = { value: 10 };
let b = a;

console.log(a); // what happens here is that the object is stored in a memory location and the memory location is stored in a variable
console.log(b);

//for primitive
let digit = 5;

function numbers(digit) {
  digit++;
}

numbers(digit);
console.log(digit); // the variable is completely independent from the parameter in the numbers function even if they bear the same name.
//digit will increase to 6 within the scope of the numbers function, outside the function it'll return to 5

//for reference

let objDigit = { number: 10 };

function objNumbers(objDigit) {
  objDigit.number++;
}

objNumbers(objDigit);

console.log(objDigit);

let love = { l: 9 };

function loveFunction(love) {
  love.l++;
}

loveFunction(love);

console.log(love);

var phoneCode = {
  nigeria: "+234",
  america: "+1",
  uk: "+44",
  dubai: "+971", //data properties and methods
  canada: "+1", //literal object is to call the properties direct

  display(america) {
    return (this.america = america); // behaviour
  },
};

const myDatValue = "1.75m";
const myOwn = "12kg";
phoneCode.myDataName = "balloom";
/*or */ phoneCode["myuNewName"] = "Jenny";
console.log(phoneCode);

const myDataName = "Jenny"; // i want myDataName to be a property of an bject not in variable & value form
const myHeight = "1.75m";
const myOwn1 = "12KG";
phoneCode[myDataName] = myHeight; // height: "1.75m";
phoneCode.myDataName = myHeight;
console.log(`this is your new property ${phoneCode.Jenny}`);

console.log(phoneCode);

const color = "red";
const name1 = "lilian";
const value = 34;
phoneCode[name1] = color;
phoneCode.name1 = value;
console.log(`thsis is the new object ${phoneCode.lilian}`);

//when we need to wrap objects together in an enclosed body uding an object literal

//constructorfunction

function Human(name, age) {
  this.name = name;
  this.age = age;
}

//this keyword creates a template for the objectts tha's going to be created from the human function
// constructors are used to make multiple instances of the constructor

let persons1 = new Human("Frank", 21);
console.log(persons1);

let persons2 = new Human("Franki1", 22);
console.log(persons2);

//factories

function p(name, age) {
  return {
    name,
    age,
  };
}

let o = p("Queen", 32);
console.log(o);

let aB = p("HALA", 18);
console.log(aB);

//prototype

let dup = Object.create(phoneCode); // i want to create another type of phoneCode object
//phoneCode acts as a prototype to dup
console.log(dup); //object clone -> prototyping majorly used to inherit the featurs of a praticular opbject

function Human(name, age) {
  this.n = name;
  this.a = age;
  this.tt = function () {
    console.log("Helo World");
  };
}

/*(let person6 = new Human('Kemi', 21);
let person7 = new Human('Jenny', 21); */

console.log(new Human("jj", 4)); //undefined -> you can't console an constructor by itself by passing the values without the new keyword

/*console.log(person6);
console.log(person7);*/

/*person5.myM = function(){
    console.log("I'm a person5 object")
}

person5.myM();//method only private to person5 object ->private method
person5.gender = "female"; //mthod only private to person5 object-> private propertyc
console.log(person5) */

//this property references the current object that is going to be created with the constructor function
//new refers to the instance of an object that is created with a constructor fuunction
// the constructor itself isn't an object

//undefined is a primitive data type

let xxx;
console.log(`this is ${xxx}`); //undefined-> because the data type hasn't been specified since ther's no value
//console.log('this is an error'+ yyy); //reference error -> cuz we r referencing smomething that doesn't exist

const aaa = null; // the variable is empty or hold nothing;

//prototype is used to inherit from other objects the

console.log("this is the data type" + typeof aaa);

//the prototype  of Human constructor is pointing to the super Object
//it's inherited from the super object since Human wasn't inherited from any other object

function Human2(complexion, hairColor, height) {
  this.humanColor = complexion;
  var private; //var is used to declare a private variable or method

  this.color_of_Hair = hairColor;
  height = height;
  this.show_details = function () {
    // this is used to ddecalare a public variable or method
    this.private = 18;
    // return "From inside the human constructor" +this.color_of_hair + "and" + height;
    return this.private;
  };

  var privateMethod = function () {
    this.private = 18;
    return this.private;
  };
}

Human2.prototype.x = "123";
Human2.prototype.y = "012";
Human2.prototype.z = "234";
Human2.prototype.a = "112";
Human2.prototype.b = "223";

function Person2(age, qualifications, complexion, hairColor, height) {
  // invoke constructor here
  Human2.call(
    this /* current object refernecing Person2*/,
    complexion,
    hairColor,
    height
  ); // inheriting properties from the Human constructor
  this.age = age;
  this.qualifications = qualifications; //OWNED properties -> are properties which aren't inherited and a re owned by an object
  this.display_info = function () {
    console.log(this.age, this.qualifications, this.humanColor);
  };
}

//person2 have seven properties, //4 inherited from Human2

Person2.prototype = new Human2(); //a property attached to every object created with js is a prototype
//prototype is used to assess every relationship between objects

Person2.prototype.constructor = Person2; // the prototype should be pointing at Person constructor instead of the human constructor
//pthe persons2 constructor will have full control of the human constructor since the human  constructyor is inherited

// the car property is added sirectly to the human constructor
Person2.car = "true";

Person2.prototype.name = "Jenny";
Person2.prototype.surname = "Funke";
Person2.prototype.age = 25;

let person8 = new Person2(22, "BSC", "brown", "white", "6ft"); //person1
console.log(person8);

let human1 = new Human2("black", "blue", "5ft 7in");
Human2.prototype.car = "true";
//console.log(human1);
console.log(person8);
console.log(human1.car); //undefined
console.log(human1);
console.log(person8.car);

function newHouse(
  street,
  houseNo,
  storeyNo,
  age,
  qualifications,
  complexion,
  hairColor,
  height
) {
  Person2.call(this, age, qualifications, complexion, hairColor, height);
  this.streetName = street;
  this.no = houseNo;
  this.storey = storeyNo;
}

newHouse.prototype = new Person2(); // the newHouse prototype is inheriting from person2 constructor
newHouse.prototype.constructor = newHouse; // setting back the newHouse construtctor to itself so that the newHouse will fully inherit the person 2 constructor
Person2.prototype.car = "true";
let n1 = new newHouse("Fashola St", 4, 4, 25, "BSC"); // u don't have to include all the properties
console.log(n1);
console.log(n1.car);
console.log(`The object inherited are ${n1.qualifications}`);
n1 instanceof newHouse;

//call is used on a function to bind the function's parameters with an object

let func = function () {
  console.log(2 * 3);
};

func.call(Human); // binding func to the Human function
//argumants I passed during invocation

let human = {
  names: "Jenny",
  age: 12,
};
for (let hum in human) {
  if (hum.hasOwnProperty(names)) {
    console.log("Yes");
  } else {
    console.log("False");
  }
}

function external1(outer) {
  outer++;
  console.log("This is an outer variable" + outer);

  return function inner(innerNo) {
    let add = outer + innerNo;
    console.log(`This is the number inside the inner function ${innerNo}`);
    console.log("This is the addition of two numbers" + add);
  };
}

let innerFunction = external1(10);
innerFunction(20);

//arrays

let arr = [
  "Jenny",
  "james",
  "chidera",
  "joshua",
  "aisha",
  "wale",
  "raheem",
  "eseohe",
];
let emptyArr = [];

//forEach is used to do somethng eith each element of the array
let select = function () {
  for (let index = 0; index <= arr.length; index++) {
    // if the index is greater than 0, then it needs to reduce because after the iteration the index will be incremented to then-> // let deletedEl = arr.splice(index, 1)
    //the index in deletedElemented will become 1 then it's chidera taht
    if (index > 0) {
      index--;
      let deletedEl = arr.splice(index, 1); // takes the index to start the cutting and how many elements do i want to cut //1 element
      //splice reduces the length the array// at the first iteration the elements will reduce from 8 to 7

      emptyArr.push(deletedEl);
    } else {
      let deletedEl = arr.splice(index, 1); // takes the index to start the cutting and how many elements do i want to cut //1 element
      //splice reduces the length the array// at the first iteration the elements will reduce from 8 to 7

      emptyArr.push(deletedEl);
    }
    //if the index is at 3 the function should stop
    if (arr.length == 4) {
      break;
    }
  }
  console.log(emptyArr);
  console.log(arr);
};
select();

//to cut an array use splice or slice

//at the first iteration, jenny has been cut off so that james will have index 0 since the length of the array has reduced from 8 to 7

let names2 = ["Jenny", "Kiki", "lawrence", "ogbonna"];
let namesArr = [];
let deletedName;

let nameFunction = function () {
  for (let index = 0; index < names2.length; index++) {
    if (index < 0) {
      index--;
      deletedName = names2.splice(index, 1);
      namesArr.push(deletedName);
    } else {
      deletedName = names2.splice(index, 1);
      namesArr.push(deletedName);
    }

    if (index == 3) {
      break;
    }
  }
};
nameFunction();
console.log(names2);
console.log(namesArr);

let newNames = [
  "kiti",
  "fayo",
  "bunsen",
  "taiwo",
  "kenny",
  "lily",
  "seth",
  "trevor",
];
let newArr2 = [];
let newNameArr = [];
let new2;
let deletedName2;
let newNameFunction = function () {
  for (let n = 0; n < newNames.length; n++) {
    new2 = newNames.map((capital) => {
      return capital.charAt(0).toUpperCase() + capital.slice(1);
    });

    if (n < 0) {
      n--;
      deletedName2 = new2.splice(n, 1);

      //capital.style.textTransform = "capitalize";

      newNameArr.push(deletedName2);
    } else {
      deletedName2 = newNames.splice(n, 1);

      let upper = deletedName2.toString();
      let capitalLetters = upper.toUpperCase();
      newNameArr.push(capitalLetters);
      console.log(capitalLetters);
    }

    if (n == 4) {
      break;
    }
  }
};

newNameFunction();

console.log(deletedName2);
console.log(new2);
console.log(newNameArr);

let x1 = {
  y1: { z: 1 },
};

x1.y1.z; // x1 is the object to y1 , y1 to property to x1, y1 is the object to the z, z is the property to y1- > alsow works in prototype
//prototype is a property to every function whether coinstructor or not the prototype property is given by default and also to arrays but the prototype on its own is an object

//Human.prototype.x = "123"
//prototype is a property where the object is created and since it acts as an object, it will tell u the name of the constructor that created the object and also points to another prototype that points to the super object that ends the prototype chain

let naming = [
  "Jasmine",
  "Joseph",
  "Jinka",
  "Jude",
  "Jane",
  "Jennifer",
  "Justin",
];
let namingArr = [];
let d;

let select2 = function () {
  for (let i = 0; i < naming.length; i++) {
    if (i > 0) {
      i--;
      d = naming.splice(i, 1);
      namingArr.push(d);
    } else {
      d = naming.splice(i, 1);
      namingArr.push(d);
    }

    if (naming.length == 4) {
      break;
    }
  }
};

let e = {
  f: {
    g: 1,
  },
};

e.f.g = 1;
//e.prototype.g = 1;

select2();
console.log(naming);
console.log(namingArr);

//array should contain 10 images
/*let imageHolder ;
let i = 0;

function imageFunction(){
 let images = ["images/foodstuff.jpg", "images/butter.jpg", "images/thyme.jpg", "images/malt.jpg",

  "images/beans.jpg", "images/poundoYam.jpg", "images/oil.jpg", "images/garri.jpg", "images/hairProducts.jpg","images/fish.jpg"];
  var pictures = document.querySelector(".picture");


  if(i < images.length){ 
    
    pictures.src= images[i];  
    i++; //closure
  }
  else{
    i = 0;
    pictures.src= images[i];
  }



  /*for(let i = 0; i<5; i++){  //we can't use for loops because the for loop will release the last element of the array once the condition is false
    pictures.src = images[i];//last value of iteration;

   console.log(images[i]);
  }
 
  
  
}


imageHolder = setInterval( imageFunction, 3000)
 
 console.log(images);


*/

let newimageHolder2;
let j = 0;
function show() {
  let imagesH = [
    "images/foodstuff.jpg",
    "images/butter.jpg",
    "images/thyme.jpg",
    "images/malt.jpg",

    "images/beans.jpg",
    "images/poundoYam.jpg",
    "images/oil.jpg",
    "images/garri.jpg",
    "images/hairProducts.jpg",
    "images/fish.jpg",
  ];

  var pictures2 = document.querySelector(".picture");

  if (j < imagesH.length) {
    pictures2.src = imagesH[j];
    j++;
  } else {
    j = 0;
    pictures2.src = imagesH[j];
  }
}

newimageHolder2 = setInterval(show, 1000);

let index2 = 0;
let carousel = function () {
  let newImages = [
    "images/foodstuff.jpg",
    "images/butter.jpg",
    "images/thyme.jpg",
    "images/malt.jpg",

    "images/beans.jpg",
    "images/poundoYam.jpg",
    "images/oil.jpg",
    "images/garri.jpg",
    "images/hairProducts.jpg",
    "images/fish.jpg",
  ];

  let randomImage = Math.floor(Math.random() * newImages.length); //+1 in case you want the number to be between 1 and 10 instead of 0 to 9;
  let sour = (docuemtn.getElementById("carousel").src = newImages[randomImage]);
  let imageIndex = document.querySelector("#image0-index");
  imageIndex.innerHTML = randomImage;
  let imageName = document.querySelector("#image-name");
};

let imageCarousel = setInterval(carousel, 2500);

let arr1 = [1, 2, 3, 4, 5];

arr1.sort((a, b) => {
  return b - a;
});

console.log(arr1);

//private variables

//to create multiple  balls from a single
var phoneCode = {
  nigeria: "234",
  li: "89",
};

let we = phoneCode;
console.log(we);
