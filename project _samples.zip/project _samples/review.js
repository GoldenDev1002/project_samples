
let namesArray = ["jenny", "emenike", "francis", "pope", "john", "lilo"];
let emptyArray = [];

let names = function(){
    for(let i = 0; i < namesArray.length; i++){

        let firstCapital = namesArray.map((capital)=> {
          return capital.charAt(0).toUpperCase().slice(1);
        })

        if(i > 0){
            i--;
            let d = firstCapital.splice(i, 1);
            emptyArray.push(d);
        }
        else{
            let d = firstCapital.splice(i, 1);
            emptyArray.push(d);
        }

        if(namesArray.length == 3){
            break;
        }
    }
}

names();
console.log(namesArray);
console.log(emptyArray);





const reviews = [
{
    id:1,
    name: "susan smith",
    job: "web developer",
    img: "C:\Users\Jenny\Desktop\noteapp\images\lily.jfif",
    text: "I am web developer with 5 years experience and I'm passionate about creating a website to promoote your brand"
}, 
{
    id:2,
    name: "Ling LAO",
    job: "UX Designer",
    img: "C:\Users\Jenny\Desktop\noteapp\images\kwan.jfif",
    text: "My passion fo UI/ UX has led me to build meaningful projects for customer's user interactions",

},

{
    id: 3,
    name: "Maria Stopes",
    job: "Content creator",
    img: "C:\Users\Jenny\Desktop\noteapp\images\kwan.jfif",
    text: "Love creating content. Wanna read mine"
},

{
    id: 4,
    name: "Carla Stopes",
    job: "Data analyst",
    img: "C:\Users\Jenny\Desktop\noteapp\images\kwan.jfif",
    text: "I specialise in studying business models, analysing business data to make predictions that will prevent companies form finanacial losses"

}





];



const img = document.querySelector(".images");
const author = document.querySelector(".author");
const job = document.querySelector(".job");
const info = document.querySelector("#info");

const prevBtn = document.querySelector(".prev-btn");
const nextBtn = document.querySelector(".next-btn");
const randomBtn = document.querySelector(".random-btn");

//set starting item
console.log(reviews.length - 1);
let currentItem = 0;

//load initial item
window.addEventListener("DOMContentLoaded", () => {
    //console.log("the window has been loaded");
 showPerson(currentItem) // a callback function
})

//create a function to reuse the person details for each person instead of increasing the currentItem to get to the next person

function showPerson(person){//person indirectly represents a number -> index
    const item = reviews[person];
    img.src = item.img
     author.textContent = item.name;
     job.textContent = item.job;
     info.textContent = item.text;
}

//show next person

nextBtn.addEventListener("click", function(){
    currentItem++;
    //since there are four arrays in the review object, what will happen if when I click the last person an error pops up showing that we have excceeded the number of times to click, 
    //a fourth array doesn't exist that's why we need to prevent that terror from happening by using this:

    if(currentItem > reviews.length){
        // reviews.length is four , if the index of current item is greater than the number of reviews.length - 1, the current item should be reset to 0
        currentItem = 0;
    }
    showPerson(currentItem)
})

prevBtn.addEventListener("click", function(){
    currentItem--;
  // there's no index in the revies array that's less than 0, so in order to prevent an error from happening as we r trying to click to the previous person5
  if(currentItem < 0){ //if the index is less than 0
    currentItem = reviews.length - 1; // the index should be set back to the number of items in the array 
  }

  showPerson(currentItem);
})

randomBtn.addEventListener("click", function(){



 let randomBtnClick= Math.floor(Math.random()* reviews.length)


currentItem = randomBtnClick;

showPerson(currentItem);

})
