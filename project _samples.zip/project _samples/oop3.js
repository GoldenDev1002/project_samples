function Home(street, doorNumber, storeyType){
    this.StreetNo = street;
    this.door = doorNumber;
     this.storey = storeyType;
     this.homef = function(){
        console.log("My home, my future");
     }
}


let h1 = new Home("4 abiola", 4, 2);
let h2 = new Home("5 irepodun", 6, 3);

h1.securityNumber = "2333";

console.log(h1);

function owner(street, doorNumber, storeyType, newName, glasses){

    Home.call(this, street, doorNumber, storeyType);
    this.add = newName;
    this.look = glasses;
}

let o1 = new owner("4 fashiola street", 40, 3, "win road house", "4 glasses");
console.log(o1);


